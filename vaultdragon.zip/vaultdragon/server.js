var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var Promise = require('bluebird');
var product = require('./lib/object/product');
var secrets = require('./config/secrets');

mongoose.connect(secrets.database.uri, {user: secrets.database.user, pass: secrets.database.password});
mongoose.Promise = Promise; // mpromise (mongoose's default promise library) is deprecated

app.use(bodyParser.urlencoded({ extended: true })); // to support URL-encoded bodies
app.use(bodyParser.json()); // to support JSON-encoded bodies

var router = express.Router();

app.use(function(err, req, res, next) {
  if (err instanceof SyntaxError && err.status === 400) {
    res.status(400).json({error: "Invalid JSON format"});
  } else {
    res.status(500).json({error: err.message});
  }
});

router.route('/object').post(function(req, res) {
  try {
    validateRequest(req);
  } catch (err) {
    res.status(400).json({error: err.message});
    return;
  }

  product.addAll(req.body)
  .then(function(data) {
    res.json({data: data});
  })
  .catch(function(err) {
    res.status(400).json({error: err.message});
  });
});

router.route('/object/:product').get(function(req, res) {
  var timestamp = req.query.timestamp ? req.query.timestamp : null;
  product.get(req.params.product, timestamp)
  .then(function(data) {
    res.json({data: data});
  })
  .catch(function(err) {
    res.status(400).json({error: err.message});
  });
});

function validateRequest(req) {
  // allows POST data to be sent via application/json or application/x-www-form-urlencoded only
  // multipart form and plain text are not supported
  if (req.get('content-type') !== 'application/json' && req.get('content-type') !== 'application/x-www-form-urlencoded') {
    throw new Error("Invalid data type");
  }
  // accept value with string type only, this is to prevent possible integer overflow
  for (key in req.body) {
    if (typeof req.body[key] !== 'string') {
      throw new Error("Value for the key ["+key+"] must be a string");
    }
  }
}

app.use('/', router);

var port = process.env.PORT || 8080;
var server = app.listen(port);
console.log('Starting Nattawat\'s API server for Vault Dragon on port %s', port);
