var mongoose = require('mongoose');
var Schema = mongoose.Schema;
 
var ProductSchema = new Schema({
    key: {type: String, required: true},
    value: String,
    timestamp: Number
});

ProductSchema.pre('save', function(next) {
    if (!this.timestamp) this.timestamp = Math.floor(Date.now() / 1000);
    next();
});

module.exports = mongoose.model('Product', ProductSchema);
